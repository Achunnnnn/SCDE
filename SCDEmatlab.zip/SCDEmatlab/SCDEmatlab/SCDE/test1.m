clc
clear all
load('Dataset_FS.mat');
Data = Dataset.('MUSK1');
TrainIn = Data(1:ceil(end*0.7), 1:end - 1);
TrainOut = Data(1:ceil(end*0.7), end);
TestIn = Data(ceil(end * 0.7) +1 :end, 1:end-1);
TestOut = Data(ceil(end*0.7)+1 : end, end);
Train_data = [TrainIn,TrainOut];
[~,D] = size(TrainIn);
sample = ones(1,D);
s = logical(sample);
mdltest = fitcknn(TrainIn(:,s),TrainOut,'NumNeighbors',5);%？？
predicted_labels = predict(mdltest, TrainIn(:,s));
b = sum(TrainOut ~= predicted_labels)
error_rate = b / length(TrainOut);


mutal = zeros(1,D);
for i = 1 : D
    for j = 1 : D
        if(j ~= i)
            mutal(i) = mutal(i) + mutualinfo(TrainIn(:,i),TrainIn(:,j));
        end
    end
end


function h = mutualinfo(vec1,vec2)

[p12, p1, p2] = estpab(vec1,vec2);

h = estmutualinfo(p12,p1,p2);

end

