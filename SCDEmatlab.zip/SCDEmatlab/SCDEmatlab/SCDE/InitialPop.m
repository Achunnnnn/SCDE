function Pop = InitialPop(N,D)
Pop = zeros(N,D);
for i = 1:N
  for d = 1:D
    if rand() > 0.5
      Pop(i,d) = 1;
    end
  end
end
end
