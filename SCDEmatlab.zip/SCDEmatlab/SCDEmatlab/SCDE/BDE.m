function [Popu,off_fitness,gBest,gBest_individual,oldgBest,c] = BDE(Popu,pop_fitness,D,N,Train_data,c,gBest,gBest_individual,I,meansu,F,nFES,FES,oldgBest,gain,t_mi)



   
%   totalgain=sum(gain);
%    probability=gain./totalgain;

      

for i = 1:N  
    for d = 1:D
       R     = randperm(N);  
    r1    = R(1);
    r2    = R(2);
    r3    = R(3);
        value =gBest_individual(1,d)+F*(Popu(r2,d)-Popu(r1,d));
          if value>0
              MV(i,d)=1;
          else
              MV(i,d)=0;
          end
    end
 end




%  MV=unique(MV,'rows');
%  s=size(MV,1);
%  if s~=N
%  e=N-s;
%  MV2=[];
%    for i=1:e
%       for d = 1:D
%          value = Popu(r1,d)+F*(Popu(r2,d)-Popu(r3,d));
%              if value>0.5
%               MV2(i,d)=1;
%              else
%               MV2(i,d)=0;
%              end
%       end
%    end
%    MV= [MV;MV2];
%  end
 
 
    if oldgBest==gBest
        c=c+1;
    else
        c=0 ;
    end
    
    
% if c>3

% for idx=1:N    
%     for jdx=1:N
%          if idx==jdx
%             RE(idx,jdx)=0;
%           else
%              RE(idx,jdx) =RED(MV(idx,:), MV(jdx,:));  
%           end
%      end
% end



for idx=1: N
    counter=0;
   for jdx=1:N
      if idx==jdx
            RE(idx,jdx)=0;
      else 
       RE(idx,jdx) =RED(MV(idx,:), MV(jdx,:));  
      end
   end
   for jdx=1:N
%      if RE(idx,jdx) >(0.6+0.3*(nFES/FES))
   if RE(idx,jdx) >0.5
       counter=counter+1;
   end
   end
%    if counter>(0.25*N+0.25*N*(nFES/FES))
if counter>0.3*N
     [~, index]=max(RE(idx,:));
         a = find(and(MV(index, :), MV(idx, :)));   
         x = find(~ MV(idx, :));
        [~,sa] =size(a);
        sa=ceil(sa/2)+1;
   
        index = TS(t_mi(a),sa);
         MV(idx,a(index)) = 0;
       
       index = TS(-t_mi(x),sa);
         MV(idx,x(index)) = 1;
end 
            
end
    
    


 
 Offspring=MV;



Offspring=unique(Offspring,'rows');
 s=size(Offspring,1);
 if s~=N
 e=N-s;
 Offspring2=[];
   for i=1:e
      for d = 1:D
          Offspring2(i,d)=round(rand);
       end
   end
    Offspring= [Offspring;Offspring2];

 end
   


% else
%     
%      Offspring = MV;
%     for i = 1 : N
% %         if rand < 0.2
%         if rand < 0.3
%             j1 = find(Offspring(i, :));
%             j0 = find(~Offspring(i, :));
%             k1 = rand(1, length(j1)) < 1 / (length(j1) + 1);
%             k0 = rand(1, length(j0)) < 1 / (length(j0) + 1);
%             Offspring(i, j1(k1)) = false;
%             Offspring(i, j0(k0)) = true;
%         else
%             k = rand(1, D) < 1 / D;
%             Offspring(i, k) = ~Offspring(i, k);
%         end
%     end


% 
%       Offspring = MV;
%    for i = 1 : N
%         k = find(xor(Popu(i, :), MV(i, :)));
%         t = length(k);
%         if t > 1
%             j = k(randperm(t, randi(t - 1, 1)));
%             Offspring(i, j) = Popu(i, j);
%         end
%         
%    end
%     
%    
%    
%    
% end
%   jrand = randi([1,D]);
%    CR=0.9;
%     for d = 1:D
%         if rand() <= CR  ||  d == jrand
%             Offspring(i,d) = MV(i,d);
%         else
%             Offspring(i,d) = Popu(i,d);
%         end
%     end
% end
off_fitness = Evaluation(Offspring,N,D,Train_data);

% [~,lBest_idx]=min(off_fitness);
% lBest_indicidual=Popu(lBest_idx,:);

for i = 1:N
    if off_fitness(i) <= pop_fitness(i)
        Popu(i,:) = Offspring(i,:);
        pop_fitness(i) = off_fitness(i);
    end
    if pop_fitness(i) < gBest
        gBest = pop_fitness(i);
        gBest_individual  = Popu(i,:);
    end
end
oldgBest=gBest;
end
function index = TS(t_mi,sa)
% Binary tournament selection
if isempty(t_mi)
index = [];
else
% n=randi(t-1,1);
index = TournamentSelection(sa,1,t_mi);
end
end
