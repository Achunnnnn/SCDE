 function gain = information_gain(X, y)
% 计算信息增益
% 输入参数：
%   X: 特征矩阵，每一行表示一个样本，每一列表示一个特征
%   y: 类别标签向量，每个元素表示对应样本的类别
% 输出参数：
%   gain: 每个特征的信息增益向量，与特征的列顺序对应

num_samples = size(X, 1);
num_features = size(X, 2);
gain = zeros(1, num_features);

% 计算整个数据集的熵
p = histcounts(y) / num_samples;
entropy_Y = -sum(p .* log2(p + eps));

% 计算每个特征的信息增益
for i = 1:num_features
    % 计算当前特征的熵
    values = unique(X(:, i));
    entropy_Xi = 0;
    for j = 1:length(values)
        idx = X(:, i) == values(j);
        p = histcounts(y(idx)) / sum(idx);
        entropy_Xi = entropy_Xi - sum(p .* log2(p + eps)) * sum(idx) / num_samples;
    end
    % 计算信息增益
    gain(i) = entropy_Y - entropy_Xi;
end

end