function f = Evaluation(X,N,D,trainData)
    train_in = trainData(:,1:D);
    train_out = trainData(:,end);
    f = zeros(1,N);
    for idx=1:N
        s=[];
        s=logical(X(idx,:));
        while sum(s) == 0
            s= logical(round(rand(1 , size(s,2))));
        end
        mdltest = fitcknn(train_in(:,s),train_out,'NumNeighbors',5);
        c = crossval(mdltest,'KFold',10);
        ff = kfoldLoss(c);
        f(idx) = ff;
    end
end